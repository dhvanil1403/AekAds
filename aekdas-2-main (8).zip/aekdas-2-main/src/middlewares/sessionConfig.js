module.exports = {
    secret: 'kinjal123',  // Use a strong secret in production
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }  // Set to true if using HTTPS
  };